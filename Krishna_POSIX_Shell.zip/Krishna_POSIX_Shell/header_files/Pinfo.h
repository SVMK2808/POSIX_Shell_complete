#ifndef PINFO_H
#define PINFO_H

#include <vector>
#include <string>

void pinfo_cross_platform(pid_t pid);

#endif