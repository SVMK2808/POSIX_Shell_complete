#ifndef SEARCH_H
#define SEARCH_H

#include <string>
#include <vector>

void handleSearchCommand(const std::vector<std::string> &args);
#endif
