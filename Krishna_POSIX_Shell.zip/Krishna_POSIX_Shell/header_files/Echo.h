#ifndef ECHO_H
#define ECHO_H

#include <vector>
#include <string>

void echoCommand(const std::vector<std::string> &tokens);

#endif