#ifndef LS_COMMAND_H
#define LS_COMMAND_H

#include <string>
#include <vector>

void ls(int argc, std::vector<std::string> &input);
#endif