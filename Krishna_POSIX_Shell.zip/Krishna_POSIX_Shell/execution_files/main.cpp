#include "Shell.h"

int main()
{
    Shell shell;
    shell.run(); // to start the shell loop
    return 0;
}