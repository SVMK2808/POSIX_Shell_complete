#pragma once
#include <string>
#include <vector>

namespace RedirectionHandler
{
    void handleRedirection(std::vector<std::string> &tokens);
}